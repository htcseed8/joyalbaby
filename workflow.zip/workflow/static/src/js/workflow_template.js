openerp.workflow=function(instance,local){
	var QWeb = instance.web.qweb;
	local.Country = instance.Widget.extend({
    start: function() {
		console.log('working');
        this.$el.append(QWeb.render("workflow_country"));
		//$('#datatable').DataTable();
    },
});

 instance.web.client_actions.add('workflow.employee.qweb', 'instance.workflow.employee');

}





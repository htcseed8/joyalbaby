from openerp import models, fields, api

class workflow_country(models.Model):
    _name='workflow.country'
    _rec_name='country_name'
	
    country_id=fields.Char('Country ID',required=True,size=6)
    country_name=fields.Char('Country Name',required=True,size=40)
    currency=fields.Char('Currency',required=True,size=30)

class workflow_state(models.Model):
	_name='workflow.state'
	_rec_name='state_name'
	
	state_id=fields.Char('State ID',required=True,size=6)
	state_name=fields.Char('State Name',required=True,size=40)
	state_country_ref=fields.Many2one('workflow.country','Country',required=True)
	
class workflow_company(models.Model):
	_name='workflow.company'
	_rec_name='company_name'
	
	company_id=fields.Char('Company ID',required=True,size=6)
	company_name=fields.Char('Company Name',required=True,size=40)
	email=fields.Char('Email Address',size=30)
	phone=fields.Char('Contact Number',size=13)
	
class workflow_branch(models.Model):
	_name='workflow.branch'
	_rec_name='branch_name'
	
	branch_id=fields.Char('Branch ID',required=True,size=6)
	branch_name=fields.Char('Branch Name',required=True,size=40)
	branch_email=fields.Char('Email Address',size=30)
	branch_phone=fields.Char('Contact Number',size=13)
	branch_company_ref=fields.Many2one('workflow.company','Company',required=True)

class workflow_address(models.Model):

	_name='workflow.address'
	_rec_name='city'
	
	address_id=fields.Char('Address',required=True,size=6)
	door_no=fields.Char('Door/House No',size=16)
	street_name=fields.Char('Street Name',required=True,size=30)
	city=fields.Char('City',required=True,size=30)
	pincode=fields.Integer('Pin Code',required=True)
	address_state_ref=fields.Many2one('workflow.state','State',required=True)
	address_country_ref=fields.Many2one('workflow.country','Country',required=True)
	
class workflow_employee(models.Model):
	_name='workflow.employee'
	_rec_name='employee_name'
	
	employee_id=fields.Char('Employee ID',required=True,size=6)
	employee_image=fields.Binary('Employee Image')
	employee_name=fields.Char('Employee Name',required=True,size=20)
	date_of_birth=fields.Date('Date of Birth',required=True)
	date_of_joining=fields.Date('Date of Joining',required=True)
	personal_email=fields.Char('Personal Email Address',required=True,size=30)
	employee_comapany_ref=fields.Many2one('workflow.company','Comapny',required=True)
	company_email=fields.Char('Company Email Address',required=True,size=30)
	employee_department_ref=fields.Many2one('workflow.department','Department',required=True)
	employee_branch_ref=fields.Many2one('workflow.branch','Branch',required=True)
	aadhar_no=fields.Char('Aadhar Number',required=True,size=12)
	pan_no=fields.Char('PAN Number',size=10)
	passport_no=fields.Char('Passport No',size=12)
	employee_contact_no=fields.Char('Contact No',required=True,size=12)
	
class workflow_department(models.Model):
	_name='workflow.department'
	_rec_name='department_name'
	
	department_id=fields.Char('Department ID',required=True,size=6)
	department_name=fields.Char('Department Name',required=True,size=30)
	
class workflow_skills(models.Model):
	_name='workflow.skills'
	_rec_name='skill_description'
	
	skill_id=fields.Char('Skill ID',required=True,size=6)
	skill_description=fields.Char('Skill Description',size=30)
	skill_type=fields.Char('Skill Type',required=True,size=16)
	


	
	
	

	
	
